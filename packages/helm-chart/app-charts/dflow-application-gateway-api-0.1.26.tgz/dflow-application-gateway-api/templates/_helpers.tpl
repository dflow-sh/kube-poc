{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dflow-application.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dflow-application.labels" -}}
app.kubernetes.io/managed-by: dflow
app.kubernetes.io/part-of: {{ .Release.Namespace | quote }}
helm.sh/chart: {{ include "dflow-application.chart" . }}
{{ include "dflow-application.selectorLabels" . }}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "dflow-application.annotations" -}}
dflow.sh/created-by: {{ .Values.dflow.username | quote }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dflow-application.selectorLabels" -}}
app.kubernetes.io/name: {{ .Values.dflow.appName | quote }}
app.kubernetes.io/component: application
{{- end }}

{{/*
Removes characters that are invalid for kubernetes resource names from the
given string
*/}}
{{- define "dflow-name-sanitize" -}}
{{ regexReplaceAll "[^-a-z0-9]*" . "" }}
{{- end }}

{{/*
Resource name sanitization and truncation.
- Always suffix the sha1sum (40 characters long)
- Always add an "r" prefix to make sure we don't have leading digits
- The rest of the characters up to 63 are the original string with invalid
character removed.
*/}}
{{- define "dflow-truncate" -}}
{{ print "r" (trunc 21 (include "dflow-name-sanitize" .)) "-" (sha1sum .) }}
{{- end }}

{{/*
Application listening port
*/}}
{{- define "dflow-app-listening-port" -}}
{{ default 8080 (default (dict "appListeningPort" "8080") .Values.userConfig).appListeningPort }}
{{- end }}


{{/*
Enable/disable Gateway API HTTPs Listener Redirect
*/}}
{{- define "dflow-enable-https-redirect" -}}
{{- dig "httpsRedirect" false (.Values.userConfig | default dict) | ternary true false }}
{{- end }}
